﻿using System;
using System.Collections.Generic;
using System.Text;
using Utilities.LoggerFactory.Base;
using Utilities.LoggerFactory.Interface;

namespace Utilities.LoggerFactory
{
    public class DataBaseLogger : ILoggerFactory
    {
        public void LogError(LogInfo logInfo, Exception ex)
        {
            /* Email sending logic*/
        }

        public void LogDebug(LogInfo logInfo)
        {
            /* Email sending logic*/
        }

        public void LogWarning(LogInfo logInfo)
        {
            /* Email sending logic*/
        }
    }
}
