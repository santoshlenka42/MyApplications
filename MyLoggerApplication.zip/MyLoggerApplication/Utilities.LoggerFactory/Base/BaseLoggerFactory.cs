﻿using System;
using System.Collections.Generic;
using System.Text;
using Utilities.LoggerFactory.Interface;

namespace Utilities.LoggerFactory.Base
{
    public abstract class BaseLoggerFactory
    {
        public abstract ILoggerFactory GetLoggerFactory(string logType);
    }
}
