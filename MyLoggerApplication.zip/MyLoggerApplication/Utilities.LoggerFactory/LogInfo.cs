﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities.LoggerFactory
{
    public class LogInfo
    {
        private int eventId = 0;
        private int priority = 0;
        private string title = null;
        private string message = null;
        public int EnventId 
        {
            set { eventId = value; }
            get { return eventId; }
        }

        public int Priority
        {
            set { priority = value; }
            get { return priority; }
        }

        public string Title
        {
            set { title = value; }
            get { return title; }
        }

        public string Message
        {
            set { message = value; }
            get { return message; }
        }
    }
}
