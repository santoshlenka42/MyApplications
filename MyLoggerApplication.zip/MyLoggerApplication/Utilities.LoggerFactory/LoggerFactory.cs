﻿using System;
using System.Collections.Generic;
using System.Text;
using Utilities.LoggerFactory.Base;
using Utilities.LoggerFactory.Interface;

namespace Utilities.LoggerFactory
{
    public class LoggerFactory: BaseLoggerFactory
    {
        public override ILoggerFactory GetLoggerFactory(string loggerType)
        {
            switch (loggerType)
            {
                case "File":
                    return new FileLogger();
                case "Database":
                    return new DataBaseLogger();
                default:
                    return new FileLogger();
            }
        }
    }
}
