﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using Utilities.LoggerFactory.Base;
using Utilities.LoggerFactory.Interface;

namespace Utilities.LoggerFactory
{
    public class FileLogger: ILoggerFactory
    {
        private string _loggerPath = @"F:\Logger\";

        public void LogError(LogInfo logInfo, Exception ex)
        {
            using (StreamWriter strWrt = new StreamWriter(string.Concat(_loggerPath, "Error_", DateTime.Now.ToString("ddMMyyyy"), ".txt"), true))
            {
                strWrt.WriteLine(String.Concat(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture), "||", logInfo.Title, "|", logInfo.Message, "|", ex.Message));
            }
        }

        public void LogDebug(LogInfo logInfo)
        {
            using (StreamWriter strWrt = new StreamWriter(string.Concat(_loggerPath, "Debug_", DateTime.Now.ToString("ddMMyyyy"), ".txt"), true))
            {
                strWrt.WriteLine(String.Concat(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture), "||", logInfo.Title, "|", logInfo.Message));
            }
        }

        public void LogWarning(LogInfo logInfo)
        {
            using (StreamWriter strWrt = new StreamWriter(string.Concat(_loggerPath, "Warning_", DateTime.Now.ToString("ddMMyyyy"), ".txt"), true))
            {
                strWrt.WriteLine(String.Concat(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture), "||", logInfo.Title, "|", logInfo.Message));
            }
        }
    }
}
