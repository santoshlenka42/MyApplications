﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities.LoggerFactory.Interface
{
    public interface ILoggerFactory
    {
        void LogError(LogInfo logInfo, Exception ex);

        void LogDebug(LogInfo logInfo);

        void LogWarning(LogInfo logInfo);
    }
}
