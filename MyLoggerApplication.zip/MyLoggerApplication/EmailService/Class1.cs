﻿using System;

namespace EmailService
{
    public class Class1
    {
    }
}
