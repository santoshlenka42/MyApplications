﻿using Microsoft.Extensions.DependencyInjection;
using System;
using Utilities.EmailService;
using Utilities.LoggerFactory;
using Utilities.LoggerFactory.Base;
using Utilities.LoggerFactory.Interface;


namespace MyLoggerApplication
{
    public delegate double GetDivision(int x, int y);
    public class Program
    {
        static void Main(string[] args)
        {
            MathFactory obj = new MathFactory();
            GetDivision del = new GetDivision(obj.Division);

            del(10, 0);
        }
    }
}
