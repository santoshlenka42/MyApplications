﻿using System;
using System.Collections.Generic;
using System.Text;
using Utilities.EmailService;
using Utilities.LoggerFactory;
using Utilities.LoggerFactory.Base;
using Utilities.LoggerFactory.Interface;

namespace MyLoggerApplication
{
    public class MathFactory
    {
        private IEmailClient _emailClient = null;
        
        ILoggerFactory _logger = null;
        public MathFactory()
        {
            _emailClient = new EmailClient();
            BaseLoggerFactory factory = new LoggerFactory();
            _logger = factory.GetLoggerFactory("File");
        }
        public double Multiply(double value)
        {
            return value * 2;
        }

        public double Square(double value)
        {
            return value * value;
        }

        public double Division(int input1, int input2)
        {
            try
            {
                return input1 / input2;
            }
            catch (Exception ex)
            {
                _logger.LogError(new LogInfo() { Message = "Text Exception Log", Title = "ConsoleApplication" }, ex);
                _emailClient.SendEmail("santoshlenka.tech@gmail.com", "Text Exception Log", ex.Message);
            }
            return 0;
        }
    }
}
