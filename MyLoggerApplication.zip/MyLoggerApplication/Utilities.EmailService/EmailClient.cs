﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace Utilities.EmailService
{
    public class EmailClient : IEmailClient
    {
        private readonly string host = "smtp.gmail.com";
        private readonly int port = 587;
        private readonly bool useSSL = true;
        private readonly string fromEmail = "santosh.lenka@gmail.com";
        private readonly string userame = "santosh.lenka@gmail.com";
        private readonly string password = "xxxxxxxxxxxxx";

        /// <summary>
        /// Sending Email
        /// </summary>
        /// <param name="toEmail"></param>
        /// <param name="subject"></param>
        /// <param name="bodyContent"></param>
        public void SendEmail(string toEmail, string subject, string bodyContent)
        {
            using (MailMessage mm = new MailMessage(fromEmail, toEmail))
            {
                mm.Subject = subject;
                mm.Body = bodyContent;
                mm.IsBodyHtml = false;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = host;
                smtp.EnableSsl = false;
                NetworkCredential NetworkCred = new NetworkCredential(userame, password);
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = port;
                smtp.Send(mm);
            }
        }

        public void SendSMSAlert(string phoneNo, string message)
        {
            /*
             * 
             * Logic to be implemented
             * 
             */
        }
    }
}
