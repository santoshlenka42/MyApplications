﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities.EmailService
{
    public interface IEmailClient
    {
        void SendEmail(string toEmail, string subject, string bodyContent);

        void SendSMSAlert(string phone, string message);
    }
}
